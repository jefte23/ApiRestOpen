package br.com.bb.ditec.gesit.capacidade.api.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import br.com.bb.ditec.gesit.capacidade.api.repositories.EmpreendimentoRepository;
import br.com.bb.ditec.gesit.capacidade.api.entities.Empreendimento;


@Service
public class EmpreendimentoService {

	//@Autowired @Getter
	//private Empreendimento empreendimento ;
	
    @Autowired
    private EmpreendimentoRepository empreendimentoRepository;

  
    @SuppressWarnings("static-access")
	public Empreendimento findById(Long id) {
		try {
			return this.empreendimentoRepository.findOne( id );
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("empreendimento não localizado! : " + id);
		}
    }
    
    @SuppressWarnings("static-access")
	public Empreendimento findByname(String name) {
		try {
			return this.empreendimentoRepository.findByNameEmpreendimento( name );
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("empreendimento não localizado! :" + name);
		}
    }
    
    public List<Empreendimento> empreendimento(){
    	return empreendimentoRepository.findAll(sortByIdDesc());
    }

    private Sort sortByIdDesc() {
        return new Sort(Sort.Direction.DESC, "dataCaderno");
    }    
  
	public EmpreendimentoRepository getEmpreendimentoService() {
		return empreendimentoRepository;
	}

	public Empreendimento cadastrarEmpreendimento(Empreendimento empreendimento) {
		return empreendimentoRepository.save(empreendimento);

    }
	
    @SuppressWarnings("static-access")
	public void  delete(Long id) {
    	this.empreendimentoRepository.delete(id);
    }

	@SuppressWarnings("static-access")
	public Object findAll() {
		return this.empreendimentoRepository.findAll();
	}

	public void updateEmpreendimento(Empreendimento empreendimento) {
		empreendimentoRepository.save(empreendimento);
		
	}

	
}
