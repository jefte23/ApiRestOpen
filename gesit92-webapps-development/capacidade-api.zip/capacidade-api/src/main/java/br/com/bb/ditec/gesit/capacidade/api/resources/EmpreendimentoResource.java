package br.com.bb.ditec.gesit.capacidade.api.resources;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.bb.ditec.gesit.capacidade.api.entities.Empreendimento;
import br.com.bb.ditec.gesit.capacidade.api.entities.Funcionario;
import br.com.bb.ditec.gesit.capacidade.api.integration.gsti.HttpClientGSTI;
import br.com.bb.ditec.gesit.capacidade.api.services.EmpreendimentoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/**
 * @author Lucas.carvalho - C1279457
 * @since 15/05/2018
 * @email - lucas.carvalho@capgemeni.com.br
 * 
 */

@ApiResponses(value = {
        @ApiResponse(code = 200, message = "Empreendimento recuperada/gravado com sucesso"),
        @ApiResponse(code = 401, message = "Você não está autorizado a visualizar o recurso"),
        @ApiResponse(code = 403, message = "O recurso que você está tentando acessar é proibido"),
        @ApiResponse(code = 404, message = "O empreendimento que você estava tentando acessar não foi encontrado"),
        @ApiResponse(code = 500, message = "Erro interno do servidor")
        
})
@Api("Recuperando um empreendimento por id")
@RestController
//@RequestMapping("/empreendimento")
public class EmpreendimentoResource {

	@Autowired
	private EmpreendimentoService empreendimentoService;
	
	/* ----------------------------------- Busca Todos ----------------------------------- */
	@GetMapping("/op4724318v1")
	@ApiOperation(value = "Empreendimentos", produces = "aplication/json", response = Empreendimento.class)
	//public ResponseEntity<List<Empreendimento>> listaServico() {
	public ResponseEntity<List<Empreendimento>> listaServico() {		
		try {
			@SuppressWarnings("unchecked")
			List<Empreendimento> emp = (List<Empreendimento>) empreendimentoService.findAll();
			return ResponseEntity.ok( emp );
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}

	}
		
	/* ----------------------------------- Busca por ID ----------------------------------- */
	@ApiOperation(value = "Consulta o empreendimento por id", notes = "Consulta síncrona", response = Empreendimento.class, produces = "application/json")
	@GetMapping
	@RequestMapping("/op4724666v1/{id}")
	public ResponseEntity<?> buscarEmpreendimentoPorID(@ApiParam(required=true, type="Long", value="id do empreendimento", format="111")   @PathVariable("id") Long id) {
		try {
			 Empreendimento emp = empreendimentoService.findById(id );
		   return ResponseEntity.ok(emp);
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}	
	
	/* -------------------------- Busca pelo nome | Codigo ----------------------------- */
	@ApiOperation(value = "Consulta o empreendimento por seu nome", notes = "Consulta síncrona", response = Empreendimento.class, produces = "application/json")
	@GetMapping
	@RequestMapping("/op4724387v1/{numEmpreendimento}")
	public ResponseEntity<?> buscarEmpreendimentoPorName(@ApiParam(required=true, type="String", value="nome do empreendimento", format="EMPT112231")   @PathVariable("numEmpreendimento") String name) {
		try {
			 Empreendimento emp = empreendimentoService.findByname(name);
		   return ResponseEntity.ok(emp);
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	/* ----------------------------------- Insere novo ----------------------------------- */
	@ApiOperation(value = "Inserir novo empreendimento no banco de dados", notes="insert da tabela", response = Empreendimento.class, produces = "application/json")
	@PostMapping
	@RequestMapping("/op4722464v1")
	public ResponseEntity<?> cadastrar(@RequestBody  @NotEmpty String empreendimento) {
		try {
			Empreendimento req = HttpClientGSTI.fromJson(empreendimento, Empreendimento.class);
			empreendimentoService.cadastrarEmpreendimento( req );
			return ResponseEntity.ok( HttpStatus.OK );
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	/* ----------------------------- Atualiza empreendimento ------------------------------ */
	@ApiOperation(value = "Inserir novo empreendimento no banco de dados", notes="insert da tabela", response = Empreendimento.class, produces = "application/json")
	@PutMapping()
	@RequestMapping("/op4724140v1")
	public ResponseEntity<?> update(@RequestBody  @NotEmpty Empreendimento empreendimento) {
		
		Long id = empreendimento.getRi();

		if( null != id ) {
			empreendimentoService.updateEmpreendimento(empreendimento);
			return ResponseEntity.ok( HttpStatus.OK );	
			
		}else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}
