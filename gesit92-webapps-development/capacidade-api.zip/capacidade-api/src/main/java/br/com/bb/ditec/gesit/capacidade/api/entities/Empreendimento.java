package br.com.bb.ditec.gesit.capacidade.api.entities;

/**
 * @author Lucas.carvalho - C1279457
 * @since 14/05/2018
 * @email - lucas.carvalho@capgemeni.com.br
 * 
 */

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//Anotacoes lambok
@Data @Getter @Setter
//@AllArgsConstructor @NoArgsConstructor 
@ToString @EqualsAndHashCode(callSuper=false)
//Anotacoes da JPA
@Entity
@Table(name="TB_PORTAL_EMPREENDIMENTO")
public class Empreendimento implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "ID_SEQ", sequenceName = "ORAIIT.SEQ_PORTAL_EMPREENDIMENTO", initialValue = 1, allocationSize = 1) 
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_SEQ")
	@Column(name="ID", nullable = false, length = 40 ,updatable = false)
    private Long ri;
	
	@Column(name="NUM_EMPREENDIMENTO", nullable = false, length = 50 ,updatable = false)
	private String dcEprd;
	
	@Column(name="DTE_CADASTRO", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", insertable = false, updatable = false)
    @Temporal(value = TemporalType.TIMESTAMP)
    private Date dataCadastro;
	
	@Column(name="NEW_PRODUTO", nullable = false, length = 50 ,updatable = true)
    private String nmPrd;
	
	@Column(name="HAS_INCREMENTO", nullable = false, length = 50 ,updatable = true)
    private String txHashAum;
	
	@Column(name="APL_QTD_CANAIS", nullable = false, length = 50 ,updatable = true)
    private String qtUsuApi;
	
	@Column(name="NME_CANAIS", nullable = false, length = 200 ,updatable = true)
    private String nmCnl;
	
	@Column(name="QTD_EQ_LOGICAS", nullable = true, length = 40, updatable = true)
	private Integer qtEqpLgc;

	
	public Empreendimento(Long ri, String dcEprd, Date dataCadastro, String nmPrd, String txHashAum,
			String qtUsuApi, String nmCnl, Integer qtEqpLgc) {
		this.ri = ri;
		this.dcEprd = dcEprd;
		this.dataCadastro = dataCadastro;
		this.nmPrd = nmPrd;
		this.txHashAum = txHashAum;
		this.qtUsuApi = qtUsuApi;
		this.qtEqpLgc = qtEqpLgc;
	}

	public Empreendimento() {
		// TODO Auto-generated constructor stub
	}
	

}
