package br.com.bb.ditec.gesit.capacidade.api.repositories;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.bb.ditec.gesit.capacidade.api.entities.Empreendimento;


@Repository
public interface EmpreendimentoRepository extends JpaRepository<Empreendimento, Serializable> {

	@Query(nativeQuery = true, value = "select * from TB_PORTAL_EMPREENDIMENTO where ID = ?")
	Empreendimento findByIdEmpreendimento(Long cp);
	
	@Query(nativeQuery = true, value = "select * from TB_PORTAL_EMPREENDIMENTO where NUM_EMPREENDIMENTO = ?")
	Empreendimento findByNameEmpreendimento(String numEmpreendimento);
}
